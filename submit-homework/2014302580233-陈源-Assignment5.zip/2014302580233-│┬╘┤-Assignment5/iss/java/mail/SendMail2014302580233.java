package iss.java.mail;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.text.AbstractDocument.Content;

public class SendMail2014302580233 implements IMailService{
	//SMTP�ʼ���������ַ
	private String smtpHost = "smtp.163.com";
	private String pop3Server = "pop3.163.com";
	//�����û���
	private String userName = "18717154816@163.com";
	//�����¼����
	private String password = "yaoubtdbeoeauuzj";
	//�������ʼ���ַ
	private String from = "18717154816@163.com";
	//�������ʼ���ַ
	private String to = "18717154816@163.com";
	private Session session;
	private Folder folder;
	private Transport transport;
	public void setSmtp(String smtpHost){
	        this.smtpHost=smtpHost;
	}
	public void setpop3(String pop3Server){
		this.pop3Server=pop3Server;
	}
	public void send1() throws NoSuchProviderException {
			Properties props = System.getProperties();
			props.put("mail.smtp.host", smtpHost);
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.auth", "true");
	
			session = Session.getInstance(props);
			transport = session.getTransport();
	}
	private  MimeMessage createMail(String recipient, String subject, Object content)throws Exception{
			
			MimeMessage message = new MimeMessage(session);
			InternetAddress fromAdress = new InternetAddress(from);
			message.setFrom(fromAdress);
			
			InternetAddress toAddress = new InternetAddress(to);
			message.addRecipient(Message.RecipientType.TO, toAddress);
			
			message.setSubject(subject);
			message.setContent(content.toString(), "text/html;charset=UTF-8");
		
			return message;
	}

	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		send1();
		Receiver receiveConnect = new Receiver();
		try {
			receiveConnect.receiver();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		if(folder==null)
			return false;
		return true;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		Message[] messages = folder.getMessages(1,2);
		for(int i=0;i<messages.length;i++){
			System.out.println("Message"+(i+1));
			messages[i].writeTo(System.out);
		}
		return sender+"\n"+subject+messages[0].getContent().toString();
	}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		try {
		transport.connect(smtpHost,userName,password);
		MimeMessage message;
		message = createMail(recipient, subject, content);
		transport.sendMessage(message, message.getAllRecipients());
		transport.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.getLogger(SendMail2014302580233.class.getName()).log(Level.SEVERE,null,e);
		}
	}

}