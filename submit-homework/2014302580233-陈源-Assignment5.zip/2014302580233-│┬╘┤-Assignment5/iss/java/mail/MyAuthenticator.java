package iss.java.mail;

import javax.mail.Authenticator;

public class MyAuthenticator extends Authenticator{
	String userName="";
	String password="";
	public MyAuthenticator(){
		
	}
	public MyAuthenticator(String userName,String password){
		this.userName=userName;
		this.password=password;
	}
	protected javax.mail.PasswordAuthentication getPasswordAuthentication(){
		return new javax.mail.PasswordAuthentication(userName, password);
	}
	
}
