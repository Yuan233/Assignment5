package iss.java.mail;

import java.io.IOException;

import javax.mail.MessagingException;

//IMailService�ӿ�
public interface IMailService {
	public void connect() throws MessagingException;
	public void send(String recipient, String subject, Object content) throws MessagingException;
	public boolean listen() throws MessagingException;
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException;
}
