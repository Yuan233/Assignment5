package iss.java.mail;

import java.util.Properties;

import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;

public class Receiver{
	private String host = "pop3.163.com";
	private String userName = "18717154816@163.com";
	private String password = "yaoubtdbeoeauuzj";
	private String provider = "pop3";
	private Folder folder;
	
	public void receiver()throws NoSuchProviderException{

		
		Properties props = System.getProperties();
		props.put("mail.store.protocol", "pop3");
        props.put("mail.pop3.host", "pop3.163.com");
        // ��֤
        MyAuthenticator authenticator = new MyAuthenticator(userName, password);
        // ����session
        Session session = Session.getInstance(props,authenticator);

		Store store = session.getStore();
		try {
			store.connect(host,userName,password);
		
		folder= store.getFolder("INBOX");
		
		folder.open(Folder.READ_ONLY);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
}		
